package org.demo35test;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.setup.MockMvcBuilders.standaloneSetup;

@SpringBootTest
@AutoConfigureMockMvc
public class ClientControllerTest2 {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private AddClientService addClientService;

    @BeforeEach
    public void setUp() {
        mockMvc = standaloneSetup(new ClientController(addClientService))
                .build();
    }
    @Test
    public void whenAddNewClientWithInvalidDataThenReturnBadRequest() throws Exception {
        // Подготовка невалидного JSON для запроса
        String invalidDtoJson = "{\"name\":\"\",\"email\":\"not-a-valid-email\"}";

        // Имитация поведения: возврат исключения при вызове addClient
        when(addClientService.addClient(any(Client.class)))
                .thenThrow(new RuntimeException("Validation failed"));

        // Выполнение запроса и проверка результатов
        mockMvc.perform(post("/clients/addNewClient")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(invalidDtoJson))
                .andExpect(status().isBadRequest());
    }


    @Test
    public void whenAddNewClientWithValidationErrorsThenReturnBadRequest() throws Exception {
        String invalidDtoJson = "{\"name\":\"\",\"email\":\"not-an-email\"}";

        mockMvc.perform(post("/clients/addNewClient")
                        .contentType("application/json")
                        .content(invalidDtoJson))
                .andExpect(status().isBadRequest());
    }


    @Test
    public void whenAddNewClientWithValidationErrorsThenExceptionThrown() throws Exception {
        mockMvc.perform(post("/clients/addNewClient")
                        .contentType("application/json")
                        .content("{\"name\":\"\",\"email\":\"not-an-email\"}"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.errors.name").exists())
                .andExpect(jsonPath("$.errors.email").exists())
                .andExpect(result -> {
                    String nameError = result.getResponse().getContentAsString();
                    assert(nameError.contains("Name is required and cannot be empty") ||
                            nameError.contains("Name must be between 2 and 100 characters long"));
                    String emailError = result.getResponse().getContentAsString();
                    assert(emailError.contains("Email should be valid"));
                });
    }
}
