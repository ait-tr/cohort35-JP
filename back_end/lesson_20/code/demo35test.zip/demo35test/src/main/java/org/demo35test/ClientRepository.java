package org.demo35test;

import org.springframework.data.jpa.repository.JpaRepository;

import java.lang.ref.Cleaner;

public interface ClientRepository extends JpaRepository<Client, Long> {
}
