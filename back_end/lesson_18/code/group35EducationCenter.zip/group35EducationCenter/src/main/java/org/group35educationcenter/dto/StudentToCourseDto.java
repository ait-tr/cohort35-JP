package org.group35educationcenter.dto;


import lombok.Data;

@Data
public class StudentToCourseDto {
    private Long userId;
}
