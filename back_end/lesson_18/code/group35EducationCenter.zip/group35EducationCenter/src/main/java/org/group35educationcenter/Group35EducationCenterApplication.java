package org.group35educationcenter;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Group35EducationCenterApplication {

    public static void main(String[] args) {
        SpringApplication.run(Group35EducationCenterApplication.class, args);
    }

}
