package org.group35educationcenter.repositories;

import org.group35educationcenter.models.Course;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CourseRepository extends JpaRepository<Course, Long> {
}
