package org.demoaysel.controller;

import lombok.RequiredArgsConstructor;
import org.demoaysel.dto.AuthorCreateRequestDto;
import org.demoaysel.entity.Author;
import org.demoaysel.service.AuthorService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/authors")
@RequiredArgsConstructor
public class AuthorController {

    private final AuthorService authorService;

    @PostMapping
    public Author createAuthor(@RequestBody AuthorCreateRequestDto requestDto){
        return authorService.createAuthor(requestDto.getAuthorName());
    }

    @GetMapping
    public List<Author> findAll(){
        return authorService.findAll();
    }

}
