package org.demoaysel.repository;

import org.demoaysel.entity.Author;
import org.demoaysel.entity.Book;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface BookRepository extends JpaRepository<Book,Integer> {

    Optional<Book> findByAuthor(Author author);

    Optional<Book> findByTitle(String title);

}
