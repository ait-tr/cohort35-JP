package org.demoaysel.service;

import lombok.AllArgsConstructor;
import lombok.Data;
import org.demoaysel.entity.Author;
import org.demoaysel.entity.Book;
import org.demoaysel.repository.AuthorRepository;
import org.demoaysel.repository.BookRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Data
@AllArgsConstructor
@Service
public class BookService {

    private final BookRepository bookRepository;

    public Book createBook(Book newBook){

        Book savedBook = bookRepository.save(newBook);
        return savedBook;
    }

    public List<Book> findAll() {
        return bookRepository.findAll();
    }
}
