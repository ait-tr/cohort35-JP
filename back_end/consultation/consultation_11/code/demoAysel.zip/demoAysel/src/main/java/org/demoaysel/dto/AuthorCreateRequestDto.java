package org.demoaysel.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class AuthorCreateRequestDto {

    private String authorName;
}
