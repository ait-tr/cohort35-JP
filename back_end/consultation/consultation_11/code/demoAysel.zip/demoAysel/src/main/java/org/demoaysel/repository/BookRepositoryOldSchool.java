package org.demoaysel.repository;

import org.demoaysel.entity.Author;
import org.demoaysel.entity.Book;
import org.hibernate.dialect.unique.CreateTableUniqueDelegate;

import java.util.ArrayList;
import java.util.List;

public class BookRepositoryOldSchool {

    List<Book> books = new ArrayList<>();

    public void createLibrary(){

        Author author1 = new Author(1, "Джек Лондон");


        Book book1 = new Book(1,"Белый клык", author1);


        books.add(book1);

        System.out.println(books);


        //CRUD (create, read, update, delete)



    }
}
