package org.demoaysel.service;

import lombok.AllArgsConstructor;
import lombok.Data;
import org.demoaysel.entity.Author;
import org.demoaysel.repository.AuthorRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Data
@AllArgsConstructor
@Service
public class AuthorService {

    private final AuthorRepository authorRepository;

    public Author createAuthor(String authorName){
        Author newAuthor = new Author();
        newAuthor.setAuthorName(authorName);
        Author savedAuthor = authorRepository.save(newAuthor);
        return savedAuthor;
    }

    public List<Author> findAll() {
        return authorRepository.findAll();
    }
}
