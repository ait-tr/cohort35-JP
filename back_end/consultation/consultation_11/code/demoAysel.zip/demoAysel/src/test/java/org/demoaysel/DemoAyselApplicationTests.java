package org.demoaysel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoAyselApplicationTests {

    @Test
    void contextLoads() {
    }

}
