package org.demoshop.google;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.view.RedirectView;
import lombok.RequiredArgsConstructor;

@RestController
@RequiredArgsConstructor
public class OAuthController {

    private final OAuthService oauthService;

    @GetMapping("/authenticate")
    public RedirectView authenticateUser() {
        // Перенаправление на страницу Google для авторизации
        String redirectUrl = oauthService.buildAuthenticationUrl();
        return new RedirectView(redirectUrl);
    }

    @GetMapping("/callback")
    public ResponseEntity<?> handleGoogleCallback(@RequestParam("code") String code, @RequestParam("state") String state) {
        // Обработка ответа от Google, обмен кода на токен
        if (oauthService.isStateValid(state)) {
            String accessToken = oauthService.exchangeCodeForAccessToken(code);
            return ResponseEntity.ok("Access Token: " + accessToken);
        }
        return ResponseEntity.badRequest().body("Invalid state parameter");
    }
}
