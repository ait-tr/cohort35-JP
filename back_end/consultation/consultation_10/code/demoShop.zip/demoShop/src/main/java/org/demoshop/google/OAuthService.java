package org.demoshop.google;

import lombok.AllArgsConstructor;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import static org.demoshop.google.AuthConstants.*;

@Service
@RequiredArgsConstructor
public class OAuthService {

    private final RestTemplate restTemplate;


    public String buildAuthenticationUrl() {
        return "https://accounts.google.com/o/oauth2/v2/auth?client_id=" + GOOGLE_CLIENT_ID +
                "&response_type=code&scope=openid%20email%20profile&redirect_uri=" + GOOGLE_REDIRECT_URL +
                "&state=STATE_STRING&prompt=consent";
    }

    public String exchangeCodeForAccessToken(String code) {
        String url = "https://oauth2.googleapis.com/token";
        MultiValueMap<String, String> map = new LinkedMultiValueMap<>();
        map.add("code", code);
        map.add("client_id", GOOGLE_CLIENT_ID);
        map.add("client_secret", GOOGLE_CLIENT_SECRET);
        map.add("redirect_uri", GOOGLE_REDIRECT_URL);
        map.add("grant_type", "authorization_code");
        return restTemplate.postForObject(url, map, String.class);
    }

    public boolean isStateValid(String state) {
        // Implement your state validation logic here
        return true;
    }
}
