package org.demoshop.google;

import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class GoogleTokenValidator {
    public boolean validateToken(String token) {
        // Simulate token validation
        return token.length() > 20; // Simple check for example purposes
    }



    public UserDetails getUserDetails(String token) {
        // Simulated user details extraction
        String url = "https://www.googleapis.com/oauth2/v1/userinfo?access_token=" + token;
        RestTemplate restTemplate = new RestTemplate();
        return restTemplate.getForObject(url, UserDetails.class);
    }
}
