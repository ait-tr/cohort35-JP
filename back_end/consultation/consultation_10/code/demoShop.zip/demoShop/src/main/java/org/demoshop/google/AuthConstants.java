package org.demoshop.google;

import org.springframework.context.annotation.Configuration;

import java.util.Arrays;
import java.util.List;

@Configuration
public class AuthConstants {

    public static final String GOOGLE_CLIENT_ID = "";

    public static final String GOOGLE_CLIENT_SECRET = ""; // указать полностью

    public static final String GOOGLE_REDIRECT_URL = "http://localhost:8080/callback";
}