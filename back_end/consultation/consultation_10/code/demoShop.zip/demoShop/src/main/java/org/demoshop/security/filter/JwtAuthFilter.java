package org.demoshop.security.filter;


import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import org.demoshop.exceptions.InvalidJwtException;
import org.demoshop.google.GoogleTokenValidator;
import org.demoshop.security.service.CustomUserDetailsService;
import org.demoshop.security.service.JwtTokenProvider;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.Map;

@Component
@RequiredArgsConstructor
public class JwtAuthFilter extends OncePerRequestFilter {

    private final JwtTokenProvider jwtTokenProvider;
    private final CustomUserDetailsService customUserDetailsService;
    private final AuthenticationEntryPoint authenticationEntryPoint;
    private final GoogleTokenValidator googleTokenValidator;

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {
        try {

            if (       request.getRequestURI().startsWith("/swagger")
                    || request.getRequestURI().startsWith("/v3")
                    || request.getRequestURI().startsWith("/auth/google/callback")
                    || request.getRequestURI().startsWith("/authenticate")
                    || request.getRequestURI().startsWith("/callback")
            ) {
                filterChain.doFilter(request, response);
                return;
            }

            String token = getTokenFromRequest(request);

            useJwtToken(token);

            if (token != null && token.contains(".")) { // Check for JWT based on structure
                useJwtToken(token);
            } else if (token != null){
                useGoogleToken(token);
            }

        } catch (InvalidJwtException e ) {
            SecurityContextHolder.clearContext();
            authenticationEntryPoint.commence(request, response, e);
            return;
        }

        filterChain.doFilter(request, response);
    }

    private void useJwtToken(String token) {
        if (StringUtils.hasText(token) && jwtTokenProvider.validateToken(token)) {
            String userName = jwtTokenProvider.getUserNameFromJWT(token);
            UserDetails userDetails = customUserDetailsService.loadUserByUsername(userName);
            Authentication authentication = new UsernamePasswordAuthenticationToken(userDetails, null, userDetails.getAuthorities());
            SecurityContextHolder.getContext().setAuthentication(authentication);
        }
    }

    private void useGoogleToken(String token) {
            if (googleTokenValidator.validateToken(token)) {
                String userName = getUserEmail(token);
                UserDetails userDetails = customUserDetailsService.loadUserByUsername(userName);
                Authentication authentication = new UsernamePasswordAuthenticationToken(userDetails, null, userDetails.getAuthorities());
                SecurityContextHolder.getContext().setAuthentication(authentication);
            }
    }

    private String getTokenFromRequest(HttpServletRequest request) {
        String bearerToken = request.getHeader("Authorization");
        if (bearerToken != null && bearerToken.startsWith("Bearer ")) {
            return bearerToken.substring(7);
        }
        return null;
    }

    public String getUserEmail(String accessToken) {
        final String url = "https://www.googleapis.com/oauth2/v1/userinfo?access_token=" + accessToken;
        RestTemplate restTemplate = new RestTemplate();
        Map<String, Object> response = restTemplate.getForObject(url, Map.class);
        return (String) response.get("email");
    }


}
