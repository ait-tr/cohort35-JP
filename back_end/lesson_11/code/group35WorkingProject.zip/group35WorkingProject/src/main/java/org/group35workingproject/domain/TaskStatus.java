package org.group35workingproject.domain;

public enum TaskStatus {
    OPEN,
    CLOSE,
    ON_HOLD
}
