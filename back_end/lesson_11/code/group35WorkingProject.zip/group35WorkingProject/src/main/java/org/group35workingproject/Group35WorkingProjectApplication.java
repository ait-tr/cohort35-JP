package org.group35workingproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Group35WorkingProjectApplication {

    public static void main(String[] args) {
        SpringApplication.run(Group35WorkingProjectApplication.class, args);
    }

}
