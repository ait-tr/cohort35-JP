package org.demo35emailapp;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.UUID;

@Service
@RequiredArgsConstructor
public class UserService {

    private final UserRepository userRepository;
    private final EmailService emailService;

    public void registerUser(String email) {
        User user = new User();
        user.setEmail(email);
        user.setConfirmationCode(UUID.randomUUID().toString());

        /*  UUID - Universal Unique Identifier
        128-bit
        8-4-4-4-12
        123a4567-e89b-12d3-a456-456789012345
         */

        user.setConfirmed(false);

        userRepository.save(user);

        emailService.sendConfirmationEmail(user);
    }


    public boolean confirmUser(String confirmationCode) {
        User user = userRepository.findByConfirmationCode(confirmationCode);
        if (user != null && !user.isConfirmed()) {
            user.setConfirmed(true);
            userRepository.save(user);
            return true;
        }

        return false;
    }

}
