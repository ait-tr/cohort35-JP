package org.demo35emailapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Demo35EmailAppApplication {

    public static void main(String[] args) {
        SpringApplication.run(Demo35EmailAppApplication.class, args);
    }

}
