package org.demo35emailapp;

import lombok.AllArgsConstructor;
import lombok.RequiredArgsConstructor;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class EmailService {

    private final JavaMailSender mailSender;

    public void sendConfirmationEmail(User user){
        SimpleMailMessage message = new SimpleMailMessage();
        message.setFrom("no-reply@mysite.com");
        message.setTo(user.getEmail());
        message.setSubject("Registration Confirmation");
        message.setText("Please confirm your registration with code: " + user.getConfirmationCode());
        mailSender.send(message);
    }


}
