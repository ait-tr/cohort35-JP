package org.weatherprojectapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WheatherProjectApiApplicationTests {

    @Test
    void contextLoads() {
    }

}
