package org.group35workingproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Group35WorkingProjectApplicationTests {

    @Test
    void contextLoads() {
    }

}
