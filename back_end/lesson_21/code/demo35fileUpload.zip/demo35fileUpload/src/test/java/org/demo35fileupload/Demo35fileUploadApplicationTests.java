package org.demo35fileupload;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Demo35fileUploadApplicationTests {

    @Test
    void contextLoads() {
    }

}
