package org.demo35fileupload.controller;

import lombok.RequiredArgsConstructor;
import org.demo35fileupload.fileService.CategoryImageService;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/product")
public class ProductImageController {
    private final CategoryImageService service;

    @GetMapping("/image/{filename}")
    public ResponseEntity<Resource> getCategoryImage(@PathVariable String filename) {
        Resource image = service.loadCategoryImage(filename);
        MediaType mediaType = MediaType.IMAGE_JPEG;
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.setContentType(mediaType);
        httpHeaders.setContentDispositionFormData(filename, filename);

        return ResponseEntity.ok()
                .headers(httpHeaders)
                .body(image);

    }
}
